<?php
/*---------------------/

This is a skin for the Thesis FrameWork that will not only get you the look and feel of http://www.brunoamaral.eu; it will also offer you a few new feature, such as:

Tweaked to work with the following plugins:
- Sociable (this theme comes with it's own style sheet for sociable, so you should disable sociable's css in the options panel.)
- Twit connect (http://wordpress.org/extend/plugins/twitconnect/)

Custom-made post information on the bottom
Custom footer
Uses @font-face with the steinem font http://www.urbanfonts.com/fonts/Steinem.htm

// Current Bugs and issues
- using apture plugin, the image source information will be shown with a larger text size;

- to use the image source information you will have to include two new custom fields in your post, image_source (the url) and image_source_name (the text you want displayed, the name of the photo or the name of the photographer)

Any questions or comments, please email me at thesiswp@brunoamaral.com 

/*---------------------*/

/* FULL WIDTH NAVIGATION */
function full_width_nav() { ?>
	<div id="nav_area" class="full_width">
		<div class="page">
			<?php thesis_nav_menu(); ?>
		</div>
	</div>
<?php }
add_action('thesis_hook_before_html','full_width_nav');
remove_action('thesis_hook_before_header', 'thesis_nav_menu');

/* SOCIAL BOOKMARKS, POWERED BY SOCIABLE */
function social_bookmarks(){ if (function_exists('sociable_html')) {echo sociable_html();} }
add_action('thesis_hook_before_headline','social_bookmarks');

/* DISPLAY IMAGE SOURCE */
function image_source() {
global $post;
$source = get_post_meta($post->ID, 'image_source', true);
$source_name = get_post_meta($post->ID, 'image_source_name', true);
  if ($source == ''){
  }else{
  ?><strong> Image copyright: </strong><?php echo '<a href="' . $source . '">' . $source_name . '</a>';
  }
}

/* SHOW POST TAGS */
function show_the_tags(){
	global $thesis;
		$post_tags = get_the_tags();
		
		if ($post_tags) {
			$num_tags = count($post_tags);
			$tag_count = 1;
			
			if ($thesis['display']['tags']['nofollow'])
				$nofollow = ' nofollow';

					 echo __(' <strong>Tagged as</strong>:', 'thesis') . "\n";

			foreach ($post_tags as $tag) {			
				$html_before = '						<a href="' . get_tag_link($tag->term_id) . '" rel="tag' . $nofollow . '">';
				$html_after = '</a>';
				
				if ($tag_count < $num_tags)
					$sep = ', ' . "\n";
				elseif ($tag_count == $num_tags)
					$sep = "\n";
				
				echo $html_before . $tag->name . $html_after . $sep;
				$tag_count++;
			}

	}
}


/* BRACKETS WITH POST INFORMATION */
function brackets_info() {
if (  comments_open() ) {
echo '<p class="to_comments"><span class="bracket">{</span> <a href="';
the_permalink();
echo '#comments" rel="nofollow">';
comments_number(__('<span>0</span> comments', 'thesis'), __('<span>1</span> comment', 'thesis'), __('<span>%</span> comments', 'thesis'));
echo '</a>';

show_the_tags(); 
image_source();

echo '<span class="bracket">}</span></p>';
}elseif ( has_tag() ) { ?> <p class="to_comments"><span class="bracket">{</span> <?php show_the_tags(); image_source(); ?> <span class="bracket">}</span></p> <?php
}elseif  (get_post_meta($post->ID, 'image_source', true)) {?>

<p class="to_comments"><span class="bracket">{</span> <?php image_source(); ?> <span class="bracket">}</span></p> <?php
	}
}
remove_action('thesis_hook_after_post', 'thesis_comments_link');
add_action('thesis_hook_after_post', 'brackets_info');


/* CUSTOM FOOTER */
function custom_footer(){
// Add content to these columns as you see fit.
?>
<div class="footer_column one">

</div>

<div class="footer_column two">

</div>

<div class="footer_column three">

</div>
<?php
}
add_action('thesis_hook_footer','custom_footer');
